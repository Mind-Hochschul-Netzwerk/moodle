// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Modal for unilabel type grid
 *
 * @author      Andreas Grabs <info@grabs-edv.de>
 * @copyright   2025 onwards Grabs EDV {@link https://www.grabs-edv.de}
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import Modal from 'core/modal';

/**
 * The Delete/Cancel Modal.
 *
 * @class
 * @extends module:core/modal
 */
export default class GridModal extends Modal {
    static TYPE = 'UNILABELTYPE_GRID_MODAL';
    static TEMPLATE = 'unilabeltype_grid/grid_modal';
}

GridModal.registerModalType();
