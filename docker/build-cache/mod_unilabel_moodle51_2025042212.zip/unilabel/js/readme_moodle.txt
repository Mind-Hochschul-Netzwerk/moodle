Description of SortableJS import into this plugin
-------------------------------------------------

Download the latest free web version from https://github.com/SortableJS/Sortable
Direct download:
https://raw.githubusercontent.com/SortableJS/Sortable/master/Sortable.min.js

Put the file into the "js" folder in this plugin.
